import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  searchString: string = '';
  photosArray: {
    title: string,
    url: string
  }[] = [];
  page = 1;
  isLoading = false;

  constructor(private http: HttpClient, private service: DataService) { }

  ngOnInit(): void {
    this.page = 1;
  }

  onKeyUp() {
    this.page = 1;
    this.isLoading = true;
    this.photosArray = [];
    this.service.onKeyUp(this.searchString).subscribe((data: any) => {
      data.photos.photo.forEach((photo: any) => {
        this.photosArray.push({ title: photo.title, url: `https://live.staticflickr.com/${photo.server}/${photo.id}_${photo.secret}_w.jpg` })
      });
      this.isLoading = false;
    });
    this.page = 1;
  }

  onScroll() {
    this.page++;
    this.isLoading = true;
    this.service.onScroll(this.searchString, this.page).subscribe((data: any) => {
      data.photos.photo.forEach((photo: any) => {
        this.photosArray.push({ title: photo.title, url: `https://live.staticflickr.com/${photo.server}/${photo.id}_${photo.secret}_w.jpg` })
      });
      this.isLoading = false;
    });
  }

}
