import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
	providedIn: 'root'
})
export class DataService {

	constructor(private http: HttpClient) { }

	onKeyUp(searchString: string) {
		return this.http.get(`https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=6c1cf4c4d5fe283be9162eb56bae31a9&text=${searchString}&per_page=10&page=1&format=json&nojsoncallback=1`)
	}

	onScroll(searchString: string, page: number) {
		return this.http.get(`https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=6c1cf4c4d5fe283be9162eb56bae31a9&text=${searchString}&per_page=10&page=${page}&format=json&nojsoncallback=1`);
	}
}
