import { TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should call onKeyUp() method', () => {
    const fixture = TestBed.createComponent(AppComponent);
    spyOn(component, 'onKeyUp').and.callThrough();
    component.onKeyUp();
    fixture.detectChanges();
    expect(component.onKeyUp).toHaveBeenCalled();
  });

  it('should call onScroll() method', () => {
    const fixture = TestBed.createComponent(AppComponent);
    spyOn(component, 'onScroll').and.callThrough();
    component.onScroll();
    fixture.detectChanges();
    expect(component.onScroll).toHaveBeenCalled();
  });
  

});
